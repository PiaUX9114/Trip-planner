/** Public local scaffold readiness only. Never report secrets or provider configuration. */
export const dynamic = 'force-dynamic';

export function GET() {
  return Response.json(
    { status: 'ok', milestone: 'M0', integrationsConnected: false },
    { headers: { 'Cache-Control': 'no-store' } },
  );
}
