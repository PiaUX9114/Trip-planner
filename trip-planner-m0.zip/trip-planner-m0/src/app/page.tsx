const milestones = [
  { title: 'M0 - Foundation', text: 'Local scaffold, safe configuration and validation.', current: true },
  { title: 'M1 - Accounts', text: 'Supabase authentication, trips and role-based access.', current: false },
  { title: 'M2 - Itinerary', text: 'Stops, categories, editing and reorder controls.', current: false },
  { title: 'M3 - Maps', text: 'Google Maps, Places and route integrations.', current: false },
  { title: 'M4 - Calendar', text: 'Trip-native events and stop scheduling.', current: false },
  { title: 'M5 - Collaboration', text: 'Realtime edits and manual shared progress.', current: false },
  { title: 'M6 - Navigation', text: 'Foreground GPS and basic route guidance.', current: false },
  { title: 'M7 - Validation', text: 'Security, accessibility and release checks.', current: false },
] as const;

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-600 text-lg font-bold text-white" aria-hidden="true">TP</div>
            <div>
              <p className="text-base font-semibold tracking-tight text-slate-900">Trip Planner</p>
              <p className="text-xs text-slate-500">MVP engineering foundation</p>
            </div>
          </div>
          <span className="rounded-full border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-700">M0 Local scaffold</span>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-10 sm:px-8 sm:py-14">
        <section className="grid items-start gap-8 lg:grid-cols-[1.3fr_0.7fr]">
          <div>
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.18em] text-blue-700">Engineering setup</p>
            <h1 className="max-w-2xl text-3xl font-bold leading-tight tracking-tight text-slate-900 sm:text-5xl">A secure starting point for better travel planning.</h1>
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-600">The approved Trip Planner design has entered milestone M0. This starter is intentionally disconnected from external services. Accounts, trips, maps and navigation will be added in later milestones.</p>
            <div className="mt-6 flex flex-wrap gap-2" aria-label="Selected technology stack">
              {['Next.js', 'TypeScript', 'Tailwind CSS', 'Supabase planned', 'Google Maps planned'].map((item) => (
                <span key={item} className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600">{item}</span>
              ))}
            </div>
          </div>
          <aside className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="M0 status">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-400">Current milestone</p>
                <h2 className="mt-1 text-xl font-bold text-slate-900">Foundation</h2>
              </div>
              <span className="rounded-lg bg-blue-50 px-2.5 py-1.5 text-sm font-semibold text-blue-700">M0</span>
            </div>
            <div className="mt-6 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full w-[12.5%] rounded-full bg-blue-600" /></div>
            <p className="mt-2 text-xs text-slate-500">1 of 8 engineering milestones initiated</p>
            <div className="mt-6 space-y-3 border-t border-slate-100 pt-5 text-sm">
              <p className="flex items-center justify-between gap-3"><span className="text-slate-600">Live integrations</span><strong className="text-slate-800">Not connected</strong></p>
              <p className="flex items-center justify-between gap-3"><span className="text-slate-600">Paid services</span><strong className="text-slate-800">Not activated</strong></p>
              <p className="flex items-center justify-between gap-3"><span className="text-slate-600">Deployment</span><strong className="text-slate-800">Not started</strong></p>
            </div>
          </aside>
        </section>

        <section className="mt-12" aria-labelledby="roadmap-heading">
          <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
            <div><p className="text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Delivery plan</p><h2 id="roadmap-heading" className="mt-1 text-2xl font-bold text-slate-900">MVP milestones</h2></div>
            <span className="text-xs text-slate-500">Planned work, not completed product features</span>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {milestones.map((milestone) => (
              <article key={milestone.title} className={`rounded-2xl border bg-white p-5 ${milestone.current ? 'border-blue-300 shadow-sm' : 'border-slate-200'}`}>
                <div className={`mb-4 h-2 w-10 rounded-full ${milestone.current ? 'bg-blue-600' : 'bg-slate-200'}`} />
                <h3 className="text-sm font-bold text-slate-900">{milestone.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-500">{milestone.text}</p>
              </article>
            ))}
          </div>
        </section>
        <footer className="mt-12 border-t border-slate-200 pt-5 text-sm text-slate-500">Development scaffold only. Refer to README.md and docs/M0_RUNBOOK.md for local setup and security gates.</footer>
      </div>
    </main>
  );
}
