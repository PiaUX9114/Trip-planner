# Trip Planner - M0 Local Project Scaffold

This directory contains the first **implementation artifact** for the approved Trip Planner MVP. It is **M0 only**: a static status screen, PWA metadata/icons, safe environment templates, lint/typecheck/test configuration, and engineering documentation.

**NOT included:** authentication, Supabase connection, Google Maps/API integration, routes, trip persistence, paid resources, or deployment. Nothing in this folder will create accounts or cloud projects automatically.

## Requirements

- Node.js 22+ and npm.
- Internet access only when intentionally installing npm packages.
- No Google Cloud or Supabase keys are required to see the M0 screen.

## First run on a machine with npm registry access

```sh
cd trip-planner-m0
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000 in your browser. The screen describes **planned work**, not working trip features.

**Important:** `npm install` could not run in the authoring container because npm registry DNS was unavailable. Therefore the downloaded archive has no `node_modules` and no `package-lock.json`. The first successful `npm install` creates a lockfile. Keep and commit that lockfile before running CI or deploying. Do not claim build validation until the commands below succeed in a connected environment.

## Verify after installing dependencies

```sh
npm run test
npm run lint
npm run typecheck
npm run build
```

Independent no-install structure check:

```sh
node --test tests/*.test.mjs
```

Optional local check after dependencies are installed: http://localhost:3000/api/health returns a public, credential-free scaffold status.

## Environment and credentials

- `.env.example` contains **only blank placeholders** and is safe to share.
- `.env.local` is ignored by Git. Never commit credentials or copy them into examples.
- `NEXT_PUBLIC_*` values are exposed to browser clients. Never put secrets in these variables.
- Only use a restricted browser Google Maps key for browser-side Maps JavaScript functionality.
- Routes/Places server secrets must remain server-only and should be separately restricted.
- Do not create or configure billable projects without explicit user approval.
- No keys are needed in M0. The configuration intentionally does not connect to provider services.

## What is where?

- `src/app/page.tsx` - nonfunctional M0 status/roadmap screen.
- `src/app/manifest.ts` - initial installable-PWA metadata; not proof of full offline PWA readiness.
- `src/app/api/health/route.ts` - public local health response without secrets.
- `src/server/env.ts` - server-only future-provider readiness helper; not wired to APIs.
- `public/icons/` - placeholder PWA artwork.
- `docs/M0_RUNBOOK.md` - technical checklist and next gates.
- `docs/SECURITY_BASELINE.md` - authorization, secret, and API key requirements.
- `docs/ARCHITECTURE.md` - planned provider boundaries and release sequencing.
- `docs/DECISIONS.md` - M0 architectural decisions.
- `tests/` - dependency-free M0 structure tests.

## Out of scope until separate authorization

- Cloud service creation, billing, or API usage.
- Any deployment, domain configuration, or production storage.
- Supabase database migrations and RLS implementation (M1).
- Google Maps rendering and external route calls (M3).
- GPS tracking and live navigation (M6).
- Offline route downloads and native-grade guidance (later release).

## Security and privacy

A client-side hidden button is not an authorization control. Future trip data must use Supabase Row Level Security, role-aware server mutations, and versioned transactions. Private GPS, individual ETA, and personal route state must never be broadcast as shared trip data.

**Local-only** and **not production-ready**. Review `docs/M0_RUNBOOK.md` before authorizing M1.
